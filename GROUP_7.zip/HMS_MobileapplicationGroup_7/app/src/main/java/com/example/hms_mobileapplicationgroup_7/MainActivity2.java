package com.example.hms_mobileapplicationgroup_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {
    private Button pharmacyButton, homeButton;
    private ImageView appLogo;
    private CheckBox generalPracticeCheckbox, specializationCheckbox, subSpecializationCheckbox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        pharmacyButton = findViewById(R.id.button12);
        homeButton = findViewById(R.id.button11);
        appLogo = findViewById(R.id.imageView);

        generalPracticeCheckbox = findViewById(R.id.checkBox);
        specializationCheckbox = findViewById(R.id.checkBox2);
        subSpecializationCheckbox = findViewById(R.id.checkBox3);

        pharmacyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Consider adding functionality based on checkbox selections
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity2.this, MainActivity.class));
            }
        });
    }
}