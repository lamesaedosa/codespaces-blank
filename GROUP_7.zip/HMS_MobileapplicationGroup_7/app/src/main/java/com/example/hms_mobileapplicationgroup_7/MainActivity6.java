package com.example.hms_mobileapplicationgroup_7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {
    Button abot, developer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        Toolbar toolbar =findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        abot = findViewById(R.id.button8);
        developer = findViewById(R.id.button9);
        developer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity6.this, MainActivity7.class);
                startActivity(intent);

            }
        });
        abot.setOnClickListener(new View.OnClickListener() {
            @Override // Use @Override to indicate overriding the method
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity6.this, MainActivity5.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = new MenuInflater(this);
        inflater.inflate(R.menu.menu_item, menu); // Assuming menu.xml exists in res/menu
        return true;
    }

   /* @Override
    public boolean onOptionsItemSelected(@NonNull int featureId, @NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.bluetooth: // Assuming ID in menu.xml is corrected
                Toast.makeText(MainActivity6.this, "Bluetooth", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.share:  // Assuming ID in menu.xml is corrected
                Toast.makeText(MainActivity6.this, "Share", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);


        }

    }*/
}