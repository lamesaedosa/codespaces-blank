package com.example.hms_mobileapplicationgroup_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button dct;
    EditText Name,Region,Kebele,Age;
    Button exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = findViewById(R.id.editTextText);
        Region = findViewById(R.id.editTextText2);
        Kebele = findViewById(R.id.editTextText3);
        Age = findViewById(R.id.editTextText4);
        dct = findViewById(R.id.button);
        exit= findViewById(R.id.button2);


        dct.setOnClickListener(new View.OnClickListener() {
            @Override // Use @Override to indicate overriding the method
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExitConfirmationDialog();
            }
        });






    }

    private void showExitConfirmationDialog() {finish();
    }
}