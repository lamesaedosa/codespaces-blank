package com.example.hms_mobileapplicationgroup_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {
    private Button fac ,calculator, exit;
    private TextView drugCost,drugDuration;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        fac = findViewById(R.id.button);
        drugCost = findViewById(R.id.textView2);
        drugDuration = findViewById(R.id.textView3);

        calculator = findViewById(R.id.button2);
        exit = findViewById(R.id.button3);

        fac.setOnClickListener(new View.OnClickListener() {
            @Override // Use @Override to indicate overriding the method
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity4.this, MainActivity3.class);
                startActivity(intent);
            }
        });
        calculator.setOnClickListener(new View.OnClickListener() {
            @Override // Use @Override to indicate overriding the method
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
                startActivity(intent);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExitConfirmationDialog();
            }
        });


    }

    private void showExitConfirmationDialog() {finish();
    }
}