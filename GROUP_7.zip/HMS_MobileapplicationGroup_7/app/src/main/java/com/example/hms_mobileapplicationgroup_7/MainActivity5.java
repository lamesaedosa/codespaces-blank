package com.example.hms_mobileapplicationgroup_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {

    EditText editText1, editText2, editText3;
    Button buttonAdd, buttonMultiply, buttonSubtract, buttonDivide, buttonBack, buttonShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        // Find all the views by their IDs
        editText1 = findViewById(R.id.editTextText13);
        editText2 = findViewById(R.id.editTextText14);
        editText3 = findViewById(R.id.editTextText15);
        buttonAdd = findViewById(R.id.button);
        buttonMultiply = findViewById(R.id.button4);
        buttonSubtract = findViewById(R.id.button2);
        buttonDivide = findViewById(R.id.button5);
        buttonBack = findViewById(R.id.button6);
        buttonShare = findViewById(R.id.button7);

        // Set click listeners for buttons
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidInput()) {
                    double num1 = Double.parseDouble(editText1.getText().toString());
                    double num2 = Double.parseDouble(editText2.getText().toString());
                    double result = num1 + num2;
                    editText3.setText(String.valueOf(result));
                }
            }
        });

        buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidInput()) {
                    double num1 = Double.parseDouble(editText1.getText().toString());
                    double num2 = Double.parseDouble(editText2.getText().toString());
                    double result = num1 * num2;
                    editText3.setText(String.valueOf(result));
                }
            }
        });

        buttonSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidInput()) {
                    double num1 = Double.parseDouble(editText1.getText().toString());
                    double num2 = Double.parseDouble(editText2.getText().toString());
                    double result = num1 - num2;
                    editText3.setText(String.valueOf(result));
                }
            }
        });

        buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isValidInput()) {
                    double num1 = Double.parseDouble(editText1.getText().toString());
                    double num2 = Double.parseDouble(editText2.getText().toString());
                    if (num2 == 0) {
                        // Handle division by zero error
                        Toast.makeText(MainActivity5.this, "Error: Cannot divide by zero", Toast.LENGTH_SHORT).show();
                    } else {
                        double result = num1 / num2;
                        editText3.setText(String.valueOf(result));
                    }
                }
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace with your logic to go to MainActivity6
                Intent intent = new Intent(MainActivity5.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        buttonShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace with your logic to go to MainActivity7
                Intent intent = new Intent(MainActivity5.this, MainActivity6.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidInput() {
        String num1 = editText1.getText().toString();
        String num2 = editText2.getText().toString();
        if (num1.isEmpty() || num2.isEmpty()) {
            Toast.makeText(MainActivity5.this, "Please enter both numbers", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
